   <!-- Footer -->
    <div id="footer">
        <div id="top" class="noprint"><p><span class="noscreen">Back on top</span> <a href="#header" title="Back on top ^">^<span></span></a></p></div>
        <hr class="noscreen" />
        
        <p class="style1" id="createdby">created by JohnSnow
          <!-- DON´T REMOVE, PLEASE! -->
        </p>
        <p id="copyright">&copy; johnsnow.com</p>
  </div> <!-- /footer -->