   <!-- Footer -->
    <div id="footer">
        <p  id="createdby">created by John Snow
          
        </p>
        <p id="copyright">&copy; johnsnow.com</p>
  </div> <!-- /footer -->